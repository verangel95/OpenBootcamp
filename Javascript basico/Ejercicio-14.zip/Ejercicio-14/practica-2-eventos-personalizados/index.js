

const titulo = document.getElementById("titulo");
const parrafo = document.getElementById("parrafo")



titulo.addEventListener("cambiotexto", evento =>{
    console.log(evento.detail);
    titulo.innerText = evento.detail.texto;
    titulo.style.color = evento.detail.color;
})


function cambiartexto (nuevotexto,color){
    const evento = new CustomEvent("cambiotexto",{
        detail:{
            texto:nuevotexto,
            color
        }
    })
titulo.dispatchEvent(evento);
}