
let p = document.getElementById("formulario");


console.log(p);

p.addEventListener("submit", evento =>{
    console.log(evento);
    evento.preventDefault();
})