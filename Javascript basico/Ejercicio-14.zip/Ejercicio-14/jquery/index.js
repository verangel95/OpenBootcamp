
const boton = document.getElementById("boton");

boton.addEventListener("click", ()=>{
    alert("has dado click en el boton")
})

$("#boton").on("click",()=>{
    console.log("Hola, estoy utilizando jQuery");
})